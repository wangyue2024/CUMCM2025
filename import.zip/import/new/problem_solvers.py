# problem_solvers.py (V3 - Constraint-Preserving & Enhanced Reward)

import numpy as np
import cma
from config import Config
from analytical_model import PhysicsModelAnalytical

# ===================================================================
# CostFunctionWrapper 保持不变
# ===================================================================
class CostFunctionWrapper:
    def __init__(self, cost_function, lower_bounds, upper_bounds):
        self.cost_function = cost_function
        self.lower = np.array(lower_bounds)
        self.upper = np.array(upper_bounds)
        self.range = self.upper - self.lower

    def __call__(self, x_norm: np.ndarray) -> float:
        x_norm_clipped = np.clip(x_norm, 0, 1)
        x_physical = self.lower + x_norm_clipped * self.range
        return self.cost_function(x_physical)

    def decode(self, x_norm: np.ndarray) -> np.ndarray:
        x_norm_clipped = np.clip(x_norm, 0, 1)
        return self.lower + x_norm_clipped * self.range

# ===================================================================
# 【全新】为问题三设计的、支持“约束保持”参数化的包装器
# ===================================================================
class CostFunctionWrapperQ3(CostFunctionWrapper):
    def __init__(self, cost_function, lower_bounds, upper_bounds):
        super().__init__(cost_function, lower_bounds, upper_bounds)
        self.min_interval = Config.MIN_LAUNCH_INTERVAL

    def __call__(self, x_norm: np.ndarray) -> float:
        x_norm_clipped = np.clip(x_norm, 0, 1)
        x_physical = self.lower + x_norm_clipped * self.range
        
        # 解码增量参数
        v, th, t_start, delta_12, delta_23, dt1, dt2, dt3 = x_physical
        
        # 【关键】通过构造法保证约束
        t1 = t_start
        t2 = t1 + self.min_interval + delta_12
        t3 = t2 + self.min_interval + delta_23
        
        # 将构造好的参数传入原始代价函数
        # 注意：原始代价函数现在不需要再检查约束了
        return self.cost_function(np.array([v, th, t1, t2, t3, dt1, dt2, dt3]))

    def decode(self, x_norm: np.ndarray) -> np.ndarray:
        x_norm_clipped = np.clip(x_norm, 0, 1)
        x_physical = self.lower + x_norm_clipped * self.range
        
        v, th, t_start, delta_12, delta_23, dt1, dt2, dt3 = x_physical
        
        t1 = t_start
        t2 = t1 + self.min_interval + delta_12
        t3 = t2 + self.min_interval + delta_23
        
        return np.array([v, th, t1, t2, t3, dt1, dt2, dt3])

# ===================================================================
# 问题一求解器 (保持不变)
# ===================================================================
def solve_problem_1():
    # ... (代码完全不变，此处省略) ...
    """问题一：固定策略下的遮蔽时长计算（使用鲁棒解析法）。"""
    print("\n--- 开始求解问题 1 (鲁棒解析法精确计算) ---")
    cfg = Config()
    
    v_uav_speed = 120.0
    t_launch = 1.5
    dt_det = 3.6
    
    uav_pos_0 = cfg.UAV_INITIAL_POS['FY1']
    uav_dir = (cfg.P_FALSE_TARGET[:2] - uav_pos_0[:2])
    uav_dir /= np.linalg.norm(uav_dir)
    v_vec_uav = np.array([uav_dir[0], uav_dir[1], 0]) * v_uav_speed
    
    p_launch = uav_pos_0 + v_vec_uav * t_launch
    p_det = p_launch + v_vec_uav * dt_det + 0.5 * np.array([0, 0, -cfg.G]) * dt_det**2
    t_det = t_launch + dt_det

    model = PhysicsModelAnalytical(missile_id='M1', uav_id='FY1')
    metrics = model.calculate_shielding_metrics(p_det, t_det)
    
    print("计算完成！")
    print(f"烟幕起爆时刻: {t_det:.4f} s")
    print(f"烟幕起爆位置: {np.round(p_det, 2)}")
    print(f"有效遮蔽时间区间: {[(round(s, 4), round(e, 4)) for s, e in metrics['intervals']]}")
    print(f"总有效遮蔽时长: {metrics['total_time']:.8f} s")
    return {"total_shielding_time": metrics['total_time']}

# ===================================================================
# 问题二和三的最终版求解器
# ===================================================================

def solve_problem_2_advanced():
    """问题二：高级优化策略。"""
    print("\n--- 开始求解问题 2 (高级策略: 正规化 + 重启 + 精调) ---")
    model = PhysicsModelAnalytical(missile_id='M1', uav_id='FY1')
    
    lower_bounds = [model.config.V_UAV_MIN, 0, 0.1, 0.1]
    upper_bounds = [model.config.V_UAV_MAX, 2 * np.pi, model.time_to_impact - 25, 20.0]
    
    wrapped_cost_func = CostFunctionWrapper(model.cost_function_q2, lower_bounds, upper_bounds)

    global_best_solution_norm = None
    global_best_cost = float('inf')

    num_restarts = 3
    total_evals = 15000 # 增加评估次数
    evals_per_restart = total_evals // num_restarts

    for i in range(num_restarts):
        print(f"\n--- 第 {i+1}/{num_restarts} 轮重启 ---")
        initial_guess_norm = np.random.rand(4)
        sigma0 = 0.3 # 稍大一点的初始步长，鼓励探索
        options = {'bounds': [0, 1], 'maxfevals': evals_per_restart, 'popsize': 30, 'verbose': -9}
        
        es = cma.CMAEvolutionStrategy(initial_guess_norm, sigma0, options)
        
        while not es.stop():
            solutions_norm = es.ask()
            costs = [wrapped_cost_func(s) for s in solutions_norm]
            es.tell(solutions_norm, costs)
            
            if es.countiter % 20 == 0:
                print(f"  轮次 {i+1} | 迭代 {es.countiter:4d} | 评估数 {es.countevals:5d} | 当前最优成本: {es.result.fbest:9.4f} | 步长: {es.sigma:.6f}")

        if es.result.fbest < global_best_cost:
            global_best_cost = es.result.fbest
            global_best_solution_norm = es.result.xbest
            print(f"*** 发现新的全局最优解！成本: {global_best_cost:.4f} ***")

    best_solution_physical = wrapped_cost_func.decode(global_best_solution_norm)
    final_time = -model.cost_function_q2(best_solution_physical) # 使用原始cost func做最终验证

    print("\n" + "="*50)
    print("优化完成！")
    v, th, t_l, dt_d = best_solution_physical
    print(f"最优策略: 速度={v:.2f} m/s, 方向={np.rad2deg(th):.2f}°, 投放时间={t_l:.2f}s, 延迟={dt_d:.2f}s")
    print(f"最终精确验证的最大遮蔽时长: {final_time:.4f} s")
    print("="*50)
    return {"max_shielding_time": final_time, "best_solution": best_solution_physical}


def solve_problem_3_advanced():
    """问题三：高级优化策略 (使用约束保持参数化)。"""
    print("\n--- 开始求解问题 3 (高级策略: 约束保持 + 正规化 + 重启) ---")
    model = PhysicsModelAnalytical(missile_id='M1', uav_id='FY1')

    # 【关键】定义新的、基于增量的参数边界
    # 优化变量: [v, th, t_start, delta_12, delta_23, dt1, dt2, dt3]
    lower_bounds = [model.config.V_UAV_MIN, 0, 0.1, 0.0, 0.0, 0.1, 0.1, 0.1]
    # t_start + (1+d12) + (1+d23) < T_impact
    # 粗略估计上界，给足探索空间
    upper_bounds = [model.config.V_UAV_MAX, 2*np.pi, 40.0, 15.0, 15.0, 20.0, 20.0, 20.0]
    
    # 使用新的Q3包装器
    wrapped_cost_func = CostFunctionWrapperQ3(model.cost_function_q3, lower_bounds, upper_bounds)

    global_best_solution_norm = None
    global_best_cost = float('inf')

    num_restarts = 5
    total_evals = 60000 # 增加总评估次数
    evals_per_restart = total_evals // num_restarts

    for i in range(num_restarts):
        print(f"\n--- 第 {i+1}/{num_restarts} 轮重启 ---")
        initial_guess_norm = np.random.rand(8)
        sigma0 = 0.3
        options = {'bounds': [0, 1], 'maxfevals': evals_per_restart, 'popsize': 40, 'verbose': -9}
        
        es = cma.CMAEvolutionStrategy(initial_guess_norm, sigma0, options)
        
        while not es.stop():
            solutions_norm = es.ask()
            costs = [wrapped_cost_func(s) for s in solutions_norm]
            es.tell(solutions_norm, costs)
            
            if es.countiter % 20 == 0:
                print(f"  轮次 {i+1} | 迭代 {es.countiter:4d} | 评估数 {es.countevals:5d} | 当前最优成本: {es.result.fbest:9.4f} | 步长: {es.sigma:.6f}")

        if es.result.fbest < global_best_cost:
            global_best_cost = es.result.fbest
            global_best_solution_norm = es.result.xbest
            print(f"*** 发现新的全局最优解！成本: {global_best_cost:.4f} ***")

    best_solution_physical = wrapped_cost_func.decode(global_best_solution_norm)
    # 最终验证时，也需要用包装器来解码，然后用原始函数计算
    final_time = -wrapped_cost_func(global_best_solution_norm)

    print("\n" + "="*50)
    print("优化完成！")
    v, th, t1, t2, t3, dt1, dt2, dt3 = best_solution_physical
    print(f"最优策略: 速度={v:.2f} m/s, 方向={np.rad2deg(th):.2f}°")
    print(f"  烟幕弹 1: 投放时间={t1:.2f}s, 延迟={dt1:.2f}s")
    print(f"  烟幕弹 2: 投放时间={t2:.2f}s, 延迟={dt2:.2f}s")
    print(f"  烟幕弹 3: 投放时间={t3:.2f}s, 延迟={dt3:.2f}s")
    print(f"最终精确验证的最大遮蔽时长: {final_time:.4f} s")
    print("="*50)
    return {"max_shielding_time": final_time, "best_solution": best_solution_physical}